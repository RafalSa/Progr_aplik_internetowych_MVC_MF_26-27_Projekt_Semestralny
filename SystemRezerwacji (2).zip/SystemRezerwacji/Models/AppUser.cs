using Microsoft.AspNetCore.Identity;

namespace SystemRezerwacji.Models
{
    public class AppUser : IdentityUser
    {
        public string FullName { get; set; } = "";
        public List<Reservation> Reservations { get; set; } = new();
    }
}