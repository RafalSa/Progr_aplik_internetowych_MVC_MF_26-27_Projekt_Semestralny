using System.ComponentModel.DataAnnotations;

namespace SystemRezerwacji.Models
{
    public class AvailableSlot
    {
        public int Id { get; set; }

        [Required]
        public int ServiceId { get; set; }
        public Service? Service { get; set; }

        [Required]
        public DateTime SlotDate { get; set; }

        public bool IsBooked { get; set; }
    }
}