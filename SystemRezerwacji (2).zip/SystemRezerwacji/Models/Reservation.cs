using System.ComponentModel.DataAnnotations;

namespace SystemRezerwacji.Models
{
    public class Reservation
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Wybierz termin rezerwacji")]
        public DateTime Date { get; set; }

        public string UserId { get; set; } = "";
        public AppUser? User { get; set; }

        [Required]
        public int ServiceId { get; set; }
        public Service? Service { get; set; }

        public int? AvailableSlotId { get; set; }

        [StringLength(300)]
        public string? Notes { get; set; }

        public string Status { get; set; } = "Pending";
    }
}