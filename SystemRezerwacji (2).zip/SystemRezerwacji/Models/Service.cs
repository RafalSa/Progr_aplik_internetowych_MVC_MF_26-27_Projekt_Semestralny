using System.ComponentModel.DataAnnotations;

namespace SystemRezerwacji.Models
{
    public class Service
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Nazwa usługi jest wymagana")]
        [StringLength(100)]
        public string Name { get; set; } = "";

        [Required(ErrorMessage = "Opis usługi jest wymagany")]
        [StringLength(500)]
        public string Description { get; set; } = "";

        [Required(ErrorMessage = "Cena jest wymagana")]
        [Range(1, 50000, ErrorMessage = "Cena musi być większa od 0")]
        public decimal Price { get; set; }

        public List<Reservation> Reservations { get; set; } = new();
        public List<AvailableSlot> AvailableSlots { get; set; } = new();
    }
}