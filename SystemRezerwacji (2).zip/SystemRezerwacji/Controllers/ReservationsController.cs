using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SystemRezerwacji.Data;
using SystemRezerwacji.Models;

namespace SystemRezerwacji.Controllers
{
    [Authorize]
    public class ReservationsController : Controller
    {
        private readonly AppDbContext _db;
        private readonly UserManager<AppUser> _userManager;

        public ReservationsController(AppDbContext db, UserManager<AppUser> userManager)
        {
            _db = db;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var userId = _userManager.GetUserId(User);
            var list = await _db.Reservations
                .Include(r => r.Service)
                .Where(r => r.UserId == userId)
                .OrderByDescending(r => r.Date)
                .ToListAsync();

            return View(list);
        }

        [HttpGet]
        public async Task<IActionResult> Create(int? serviceId)
        {
            var services = await _db.Services.OrderBy(s => s.Name).ToListAsync();
            ViewBag.Services = services;
            int selectedServiceId = serviceId ?? (services.FirstOrDefault()?.Id ?? 0);

            ViewBag.AvailableSlots = await _db.AvailableSlots
                .Where(s => s.ServiceId == selectedServiceId && !s.IsBooked && s.SlotDate >= DateTime.Now)
                .OrderBy(s => s.SlotDate)
                .ToListAsync();

            return View(new Reservation
            {
                ServiceId = selectedServiceId,
                Date = DateTime.Now.AddDays(1).Date.AddHours(10)
            });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Reservation model)
        {
            var userId = _userManager.GetUserId(User);
            if (string.IsNullOrEmpty(userId)) return Challenge();

            if (model.AvailableSlotId.HasValue && model.AvailableSlotId > 0)
            {
                var slot = await _db.AvailableSlots.FindAsync(model.AvailableSlotId.Value);
                if (slot != null && !slot.IsBooked)
                {
                    model.Date = slot.SlotDate;
                    slot.IsBooked = true;
                }
            }

            if (model.Date < DateTime.Now)
            {
                ModelState.AddModelError("Date", "Termin rezerwacji musi być w przyszłości.");
            }

            ModelState.Remove("UserId");
            ModelState.Remove("Status");

            if (ModelState.IsValid)
            {
                model.UserId = userId;
                model.Status = "Pending";
                _db.Reservations.Add(model);
                await _db.SaveChangesAsync();
                TempData["SuccessMessage"] = "Rezerwacja została utworzona i oczekuje na zatwierdzenie.";
                return RedirectToAction(nameof(Index));
            }

            ViewBag.Services = await _db.Services.OrderBy(s => s.Name).ToListAsync();
            ViewBag.AvailableSlots = await _db.AvailableSlots
                .Where(s => s.ServiceId == model.ServiceId && !s.IsBooked && s.SlotDate >= DateTime.Now)
                .OrderBy(s => s.SlotDate)
                .ToListAsync();

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var userId = _userManager.GetUserId(User);
            var reservation = await _db.Reservations
                .Include(r => r.Service)
                .FirstOrDefaultAsync(r => r.Id == id && r.UserId == userId);

            if (reservation == null || reservation.Status == "Cancelled")
            {
                return NotFound();
            }

            ViewBag.Services = new SelectList(await _db.Services.ToListAsync(), "Id", "Name", reservation.ServiceId);
            return View(reservation);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Reservation input)
        {
            var userId = _userManager.GetUserId(User);
            var reservation = await _db.Reservations
                .FirstOrDefaultAsync(r => r.Id == id && r.UserId == userId);

            if (reservation == null) return NotFound();

            if (input.Date < DateTime.Now)
            {
                ModelState.AddModelError("Date", "Nowy termin musi być w przyszłości.");
            }

            ModelState.Remove("UserId");
            ModelState.Remove("Status");

            if (ModelState.IsValid)
            {
                reservation.ServiceId = input.ServiceId;
                reservation.Date = input.Date;
                reservation.Notes = input.Notes;
                reservation.Status = "Pending";

                await _db.SaveChangesAsync();
                TempData["SuccessMessage"] = "Zmieniono szczegóły rezerwacji.";
                return RedirectToAction(nameof(Index));
            }

            ViewBag.Services = new SelectList(await _db.Services.ToListAsync(), "Id", "Name", input.ServiceId);
            return View(reservation);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Cancel(int id)
        {
            var userId = _userManager.GetUserId(User);
            var reservation = await _db.Reservations
                .FirstOrDefaultAsync(r => r.Id == id && r.UserId == userId);

            if (reservation != null)
            {
                reservation.Status = "Cancelled";
                if (reservation.AvailableSlotId.HasValue)
                {
                    var slot = await _db.AvailableSlots.FindAsync(reservation.AvailableSlotId.Value);
                    if (slot != null) slot.IsBooked = false;
                }
                await _db.SaveChangesAsync();
                TempData["SuccessMessage"] = "Rezerwacja została anulowana.";
            }

            return RedirectToAction(nameof(Index));
        }
    }
}