using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SystemRezerwacji.Data;
using SystemRezerwacji.Models;
using SystemRezerwacji.ViewModels;

namespace SystemRezerwacji.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly AppDbContext _db;

        public AdminController(AppDbContext db)
        {
            _db = db;
        }

        public async Task<IActionResult> Index()
        {
            var reservations = await _db.Reservations
                .Include(r => r.Service)
                .Include(r => r.User)
                .OrderByDescending(r => r.Date)
                .ToListAsync();

            var vm = new AdminDashboardViewModel
            {
                TotalServices = await _db.Services.CountAsync(),
                ActiveReservations = reservations.Count(r => r.Status == "Approved"),
                PendingReservations = reservations.Count(r => r.Status == "Pending"),
                CancelledReservations = reservations.Count(r => r.Status == "Cancelled"),
                AvailableSlotsCount = await _db.AvailableSlots.CountAsync(s => !s.IsBooked && s.SlotDate >= DateTime.Now),
                ApprovedRevenue = reservations.Where(r => r.Status == "Approved" && r.Service != null).Sum(r => r.Service!.Price),
                Reservations = reservations
            };

            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangeStatus(int id, string status)
        {
            var reservation = await _db.Reservations.FindAsync(id);
            if (reservation != null && (status == "Approved" || status == "Cancelled" || status == "Pending"))
            {
                reservation.Status = status;
                if (status == "Cancelled" && reservation.AvailableSlotId.HasValue)
                {
                    var slot = await _db.AvailableSlots.FindAsync(reservation.AvailableSlotId.Value);
                    if (slot != null) slot.IsBooked = false;
                }
                await _db.SaveChangesAsync();
                TempData["SuccessMessage"] = "Zmieniono status rezerwacji nr #" + id;
            }
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Services()
        {
            var list = await _db.Services.Include(s => s.Reservations).ToListAsync();
            return View(list);
        }

        [HttpGet]
        public IActionResult CreateService()
        {
            return View(new Service());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateService(Service model)
        {
            if (!ModelState.IsValid) return View(model);

            _db.Services.Add(model);
            await _db.SaveChangesAsync();
            TempData["SuccessMessage"] = "Dodano nową usługę: " + model.Name;
            return RedirectToAction(nameof(Services));
        }

        [HttpGet]
        public async Task<IActionResult> EditService(int id)
        {
            var service = await _db.Services.FindAsync(id);
            if (service == null) return NotFound();
            return View(service);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditService(int id, Service model)
        {
            if (!ModelState.IsValid) return View(model);

            var service = await _db.Services.FindAsync(id);
            if (service == null) return NotFound();

            service.Name = model.Name;
            service.Description = model.Description;
            service.Price = model.Price;

            await _db.SaveChangesAsync();
            TempData["SuccessMessage"] = "Zaktualizowano usługę: " + service.Name;
            return RedirectToAction(nameof(Services));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteService(int id)
        {
            var service = await _db.Services.FindAsync(id);
            if (service != null)
            {
                _db.Services.Remove(service);
                await _db.SaveChangesAsync();
                TempData["SuccessMessage"] = "Usunięto usługę.";
            }
            return RedirectToAction(nameof(Services));
        }

        public async Task<IActionResult> Slots()
        {
            ViewBag.Services = await _db.Services.OrderBy(s => s.Name).ToListAsync();
            var slots = await _db.AvailableSlots
                .Include(s => s.Service)
                .OrderBy(s => s.SlotDate)
                .ToListAsync();
            return View(slots);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateSlot(int serviceId, DateTime slotDate)
        {
            if (slotDate > DateTime.Now && serviceId > 0)
            {
                _db.AvailableSlots.Add(new AvailableSlot
                {
                    ServiceId = serviceId,
                    SlotDate = slotDate,
                    IsBooked = false
                });
                await _db.SaveChangesAsync();
                TempData["SuccessMessage"] = "Dodano nowy dostępny termin.";
            }
            return RedirectToAction(nameof(Slots));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteSlot(int id)
        {
            var slot = await _db.AvailableSlots.FindAsync(id);
            if (slot != null)
            {
                _db.AvailableSlots.Remove(slot);
                await _db.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Slots));
        }
    }
}