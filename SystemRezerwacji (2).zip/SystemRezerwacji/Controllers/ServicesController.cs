using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SystemRezerwacji.Data;

namespace SystemRezerwacji.Controllers
{
    public class ServicesController : Controller
    {
        private readonly AppDbContext _db;

        public ServicesController(AppDbContext db)
        {
            _db = db;
        }

        public async Task<IActionResult> Index()
        {
            var services = await _db.Services
                .Include(s => s.AvailableSlots)
                .OrderBy(s => s.Name)
                .ToListAsync();
            return View(services);
        }

        [HttpGet]
        public async Task<IActionResult> GetAvailableSlots(int serviceId)
        {
            var slots = await _db.AvailableSlots
                .Where(s => s.ServiceId == serviceId && !s.IsBooked && s.SlotDate >= DateTime.Now)
                .OrderBy(s => s.SlotDate)
                .Select(s => new
                {
                    id = s.Id,
                    label = s.SlotDate.ToString("dd.MM.yyyy HH:mm")
                })
                .ToListAsync();

            return Json(slots);
        }
    }
}