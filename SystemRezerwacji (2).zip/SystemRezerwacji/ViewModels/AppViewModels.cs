using System.ComponentModel.DataAnnotations;
using SystemRezerwacji.Models;

namespace SystemRezerwacji.ViewModels
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Podaj adres e-mail")]
        [EmailAddress(ErrorMessage = "Niepoprawny format adresu e-mail")]
        public string Email { get; set; } = "";

        [Required(ErrorMessage = "Podaj hasło")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = "";
    }

    public class RegisterViewModel
    {
        [Required(ErrorMessage = "Podaj imię i nazwisko")]
        public string FullName { get; set; } = "";

        [Required(ErrorMessage = "Podaj adres e-mail")]
        [EmailAddress(ErrorMessage = "Niepoprawny format adresu e-mail")]
        public string Email { get; set; } = "";

        [Required(ErrorMessage = "Podaj hasło")]
        [MinLength(6, ErrorMessage = "Hasło musi mieć minimum 6 znaków")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = "";

        [Compare("Password", ErrorMessage = "Hasła nie są identyczne")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; } = "";
    }

    public class AdminDashboardViewModel
    {
        public int TotalServices { get; set; }
        public int ActiveReservations { get; set; }
        public int PendingReservations { get; set; }
        public int CancelledReservations { get; set; }
        public int AvailableSlotsCount { get; set; }
        public decimal ApprovedRevenue { get; set; }
        public List<Reservation> Reservations { get; set; } = new();
    }
}