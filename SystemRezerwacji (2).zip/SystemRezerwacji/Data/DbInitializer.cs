using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SystemRezerwacji.Models;

namespace SystemRezerwacji.Data
{
    public static class DbInitializer
    {
        public static async Task SeedAsync(IServiceProvider services)
        {
            var context = services.GetRequiredService<AppDbContext>();
            var userManager = services.GetRequiredService<UserManager<AppUser>>();
            var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();

            await context.Database.EnsureCreatedAsync();

            string[] roles = { "Admin", "User" };
            foreach (var role in roles)
            {
                if (!await roleManager.RoleExistsAsync(role))
                {
                    await roleManager.CreateAsync(new IdentityRole(role));
                }
            }

            var adminEmail = "admin@serwis.pl";
            var adminUser = await userManager.FindByEmailAsync(adminEmail);
            if (adminUser == null)
            {
                adminUser = new AppUser
                {
                    UserName = adminEmail,
                    Email = adminEmail,
                    FullName = "Administrator Systemu",
                    EmailConfirmed = true
                };
                await userManager.CreateAsync(adminUser, "Admin123!");
                await userManager.AddToRoleAsync(adminUser, "Admin");
            }

            var clientEmail = "klient@serwis.pl";
            var clientUser = await userManager.FindByEmailAsync(clientEmail);
            if (clientUser == null)
            {
                clientUser = new AppUser
                {
                    UserName = clientEmail,
                    Email = clientEmail,
                    FullName = "Jan Kowalski",
                    EmailConfirmed = true
                };
                await userManager.CreateAsync(clientUser, "User123!");
                await userManager.AddToRoleAsync(clientUser, "User");
            }

            if (!await context.Services.AnyAsync())
            {
                var s1 = new Service
                {
                    Name = "Diagnostyka komputerowa pojazdu",
                    Description = "Pełne sprawdzenie układów elektronicznych, odczyt i kasowanie błędów sterownika oraz raport stanu technicznego.",
                    Price = 150.00m
                };
                var s2 = new Service
                {
                    Name = "Serwis klimatyzacji z ozonowaniem",
                    Description = "Uzupełnienie czynnika chłodzącego, kontrola szczelności układu oraz odgrzybianie kabiny metodą ozonowania.",
                    Price = 280.00m
                };
                var s3 = new Service
                {
                    Name = "Wymiana oleju i kompletu filtrów",
                    Description = "Wymiana oleju silnikowego wraz z filtrem oleju, powietrza oraz filtrem kabinowym i inspekcją podwozia.",
                    Price = 350.00m
                };
                var s4 = new Service
                {
                    Name = "Geometria i zbieżność zawieszenia 3D",
                    Description = "Laserowe ustawienie kątów zawieszenia przedniej oraz tylnej osi na stanowisku pomiarowym.",
                    Price = 220.00m
                };

                context.Services.AddRange(s1, s2, s3, s4);
                await context.SaveChangesAsync();

                var baseDate = DateTime.Today.AddDays(1);
                var slots = new List<AvailableSlot>
                {
                    new AvailableSlot { ServiceId = s1.Id, SlotDate = baseDate.AddHours(9), IsBooked = true },
                    new AvailableSlot { ServiceId = s1.Id, SlotDate = baseDate.AddHours(12), IsBooked = false },
                    new AvailableSlot { ServiceId = s1.Id, SlotDate = baseDate.AddDays(1).AddHours(10), IsBooked = false },
                    new AvailableSlot { ServiceId = s2.Id, SlotDate = baseDate.AddHours(14), IsBooked = true },
                    new AvailableSlot { ServiceId = s2.Id, SlotDate = baseDate.AddDays(2).AddHours(11), IsBooked = false },
                    new AvailableSlot { ServiceId = s3.Id, SlotDate = baseDate.AddDays(1).AddHours(15), IsBooked = false },
                    new AvailableSlot { ServiceId = s3.Id, SlotDate = baseDate.AddDays(3).AddHours(9), IsBooked = false },
                    new AvailableSlot { ServiceId = s4.Id, SlotDate = baseDate.AddDays(2).AddHours(13), IsBooked = false }
                };

                context.AvailableSlots.AddRange(slots);
                await context.SaveChangesAsync();

                context.Reservations.AddRange(
                    new Reservation
                    {
                        ServiceId = s1.Id,
                        UserId = clientUser.Id,
                        Date = slots[0].SlotDate,
                        AvailableSlotId = slots[0].Id,
                        Notes = "Proszę o sprawdzenie kontrolki silnika.",
                        Status = "Approved"
                    },
                    new Reservation
                    {
                        ServiceId = s2.Id,
                        UserId = clientUser.Id,
                        Date = slots[3].SlotDate,
                        AvailableSlotId = slots[3].Id,
                        Notes = "Słabe chłodzenie podczas postoju.",
                        Status = "Pending"
                    }
                );

                await context.SaveChangesAsync();
            }
        }
    }
}