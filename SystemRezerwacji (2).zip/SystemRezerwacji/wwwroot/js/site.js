function potwierdzAnulowanie() {
    return confirm("Czy na pewno chcesz anulować wybraną rezerwację?");
}

function walidujRezerwacje(event) {
    var dateInput = document.getElementById("Date");
    if (!dateInput || !dateInput.value) {
        alert("Wybierz datę i godzinę rezerwacji.");
        event.preventDefault();
        return false;
    }

    var wybranaData = new Date(dateInput.value);
    var teraz = new Date();
    if (wybranaData <= teraz) {
        alert("Termin rezerwacji musi być w przyszłości.");
        event.preventDefault();
        return false;
    }
    return true;
}

function ustawDateZTerminu(selectElem) {
    var option = selectElem.options[selectElem.selectedIndex];
    var isoDate = option ? option.getAttribute("data-iso") : null;
    if (isoDate) {
        document.getElementById("Date").value = isoDate;
    }
}

function pobierzTerminyAjax(serviceId) {
    var selectSlot = document.getElementById("AvailableSlotId");
    if (!selectSlot) return;

    selectSlot.innerHTML = '<option value="">Ładowanie terminów...</option>';

    fetch("/Services/GetAvailableSlots?serviceId=" + encodeURIComponent(serviceId))
        .then(function (res) { return res.json(); })
        .then(function (data) {
            selectSlot.innerHTML = '<option value="">-- Wybierz z puli wolnych terminów lub wskaż własną datę poniżej --</option>';
            data.forEach(function (item) {
                var opt = document.createElement("option");
                opt.value = item.id;
                opt.textContent = item.label;
                var parts = item.label.split(" ");
                var d = parts[0].split(".");
                var iso = d[2] + "-" + d[1] + "-" + d[0] + "T" + parts[1];
                opt.setAttribute("data-iso", iso);
                selectSlot.appendChild(opt);
            });
        });
}

function filtrujUslugi() {
    var input = document.getElementById("serviceSearch");
    if (!input) return;
    var fraza = input.value.toLowerCase();
    var karty = document.querySelectorAll(".service-card-item");

    karty.forEach(function (karta) {
        var tekst = karta.innerText.toLowerCase();
        karta.style.display = tekst.indexOf(fraza) > -1 ? "" : "none";
    });
}